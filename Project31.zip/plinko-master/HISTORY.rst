=======
History
=======

0.0.1(2018-11-14)
=================

+ Initial commit!
+ Added ability get pytest command input for all identified tests
+ Added ability to parse APIx and CLIx compact files
+ Added the ability to save missing feature coverage to files
+ Added Dockerfile
